%% Скрипт для анализа разрядных характеристик аккумуляторов под разным давлением
clear all; close all; clc;

%% Рисовать разрядные характеристики для каждого АКБ
is_draw_dch = 0;

%% Параметры - ЗАДАЙТЕ ВРУЧНУЮ
data_folder = 'data/';  % Папка с файлами данных

% Массив имен файлов и соответствующих давлений
file_names = {
    '0.csv',
    '200.csv',
    '400.csv',
    '600.csv',
    '800.csv',
    '1000.csv',
    '1200.csv',
    '1400.csv',
    '1200b.csv',
    '1000b.csv',
    '800b.csv',
    '600b.csv',
    '400b.csv',
    '200b.csv',
};

diary session_log.txt

pressure_values = [ 0, 200, 400, 600, 800, 1000, 1200, 1400, 1200, 1000, 800, 600, 400, 200 ]; % Соответствующие давления

start_time = 0.001;  % Время от начала эксперимента для детального анализа (в часах)

% Параметры валидации данных
min_voltage = 2;        % Минимальное допустимое напряжение
max_voltage = 4;        % Максимальное допустимое напряжение
min_time_step = 0.000001; % Минимальный шаг по времени (для фильтрации выбросов)
max_gap = 0.1;           % Максимальный допустимый разрыв во времени (в часах)

% Параметры разряда
discharge_current = 0.39; % Ток разряда, А (390 мА)

%% Проверка корректности введенных данных
if length(file_names) ~= length(pressure_values)
    error('Количество файлов и значений давления должно совпадать!');
end

num_files = length(file_names);
num_batteries = 5; % Количество аккумуляторов
fprintf('Обработка %d файлов...\n', num_files);
fprintf('Ток разряда: %.3f А\n', discharge_current);
fprintf('Время в данных: ЧАСЫ (десятичные)\n');

%% Определение направления изменения давления
[~, max_idx] = max(pressure_values);
increasing_idx = 1:max_idx;                    % Индексы возрастающей фазы
decreasing_idx = (max_idx+1):num_files;        % Индексы убывающей фазы

fprintf('Возрастающая фаза: %d файлов\n', length(increasing_idx));
fprintf('Убывающая фаза: %d файлов\n', length(decreasing_idx));

%% Функция для очистки и валидации данных
function [clean_time, clean_voltage, valid_ratio] = clean_battery_data(time_data, voltage_data, min_v, max_v, min_step, max_gap)
    % Начальная проверка на пустые данные
    if isempty(time_data) || isempty(voltage_data)
        clean_time = [];
        clean_voltage = [];
        valid_ratio = 0;
        return;
    end

    % Базовые проверки на NaN и бесконечности
    valid_mask = ~isnan(time_data) & ~isnan(voltage_data) & ...
                 ~isinf(time_data) & ~isinf(voltage_data) & ...
                 time_data >= 0;

    time_data = time_data(valid_mask);
    voltage_data = voltage_data(valid_mask);

    if isempty(time_data)
        clean_time = [];
        clean_voltage = [];
        valid_ratio = 0;
        return;
    end

    % Проверка допустимых диапазонов напряжения
    voltage_mask = voltage_data >= min_v & voltage_data <= max_v;
    time_data = time_data(voltage_mask);
    voltage_data = voltage_data(voltage_mask);

    if isempty(time_data)
        clean_time = [];
        clean_voltage = [];
        valid_ratio = 0;
        return;
    end

    % Сортировка по времени
    [time_data, sort_idx] = sort(time_data);
    voltage_data = voltage_data(sort_idx);

    % Фильтрация выбросов по времени (слишком большие скачки)
    time_diffs = diff(time_data);
    valid_time_mask = [true; time_diffs >= min_step & time_diffs <= max_gap];
    time_data = time_data(valid_time_mask);
    voltage_data = voltage_data(valid_time_mask);

    % Дополнительная фильтрация: удаление дубликатов времени
    [time_data, unique_idx] = unique(time_data, 'stable');
    voltage_data = voltage_data(unique_idx);

    % Расчет процента валидных данных
    valid_ratio = length(time_data) / length(valid_mask);

    clean_time = time_data;
    clean_voltage = voltage_data;
end

%% Загрузка и обработка данных
full_data = struct();
filtered_data = struct();
data_quality = struct();

fprintf('\n=== ЗАГРУЗКА И ОБРАБОТКА ДАННЫХ ===\n');

for file_idx = 1:num_files
    filename = file_names{file_idx};
    filepath = [data_folder filename];
    pressure = pressure_values(file_idx);

    fprintf('\nФайл %d/%d: %s (давление: %d)\n', file_idx, num_files, filename, pressure);

    % Загрузка данных из CSV
    try
        raw_data = dlmread(filepath, ',');
        fprintf('   Загружено: %d строк, %d столбцов\n', size(raw_data, 1), size(raw_data, 2));
    catch ME
        fprintf('   ОШИБКА загрузки файла: %s\n', ME.message);
        % Создаем пустые структуры для этого файла
        for bat_idx = 1:num_batteries
            full_data(file_idx).battery(bat_idx).time = [];
            full_data(file_idx).battery(bat_idx).voltage = [];
            filtered_data(file_idx).battery(bat_idx).time = [];
            filtered_data(file_idx).battery(bat_idx).voltage = [];
        end
        continue;
    end

    tim_idxs = [1, 4, 7, 10, 13 ];

    % Обработка данных для каждого аккумулятора
    for bat_idx = 1:num_batteries
        % Индексы столбцов для текущего аккумулятора
        time_col = tim_idxs(bat_idx);
        voltage_col = time_col + 1;

        % Проверка наличия столбцов
        if time_col > size(raw_data, 2) || voltage_col > size(raw_data, 2)
            fprintf('   АКБ %d: недостаточно столбцов в файле\n', bat_idx);
            time_data = [];
            voltage_data = [];
        else
            % Извлечение данных - время в ЧАСАХ (десятичные)
            time_data = raw_data(:, time_col);
            voltage_data = raw_data(:, voltage_col);

            % Время уже в часах, преобразование не требуется
        end

        % Очистка и валидация данных
        [clean_time, clean_voltage, valid_ratio] = clean_battery_data(...
            time_data, voltage_data, min_voltage, max_voltage, min_time_step, max_gap);

        % Сохранение информации о качестве данных
        data_quality(file_idx).battery(bat_idx).original_points = length(time_data);
        data_quality(file_idx).battery(bat_idx).clean_points = length(clean_time);
        data_quality(file_idx).battery(bat_idx).valid_ratio = valid_ratio;

        fprintf('   АКБ %d: %d -> %d точек (%.1f%% валидных)\n', ...
            bat_idx, length(time_data), length(clean_time), valid_ratio*100);

        % Сохранение полных данных
        full_data(file_idx).pressure = pressure;
        full_data(file_idx).filename = filename;
        full_data(file_idx).phase = 'unknown';
        full_data(file_idx).battery(bat_idx).time = clean_time;
        full_data(file_idx).battery(bat_idx).voltage = clean_voltage;

        % Фильтрация данных по времени
        if ~isempty(clean_time)
            time_filtered_idx = clean_time >= start_time;
            filtered_time = clean_time(time_filtered_idx);
            filtered_voltage = clean_voltage(time_filtered_idx);
        else
            filtered_time = [];
            filtered_voltage = [];
        end

        % Сохранение отфильтрованных данных
        filtered_data(file_idx).pressure = pressure;
        filtered_data(file_idx).filename = filename;
        filtered_data(file_idx).phase = 'unknown';
        filtered_data(file_idx).battery(bat_idx).time = filtered_time;
        filtered_data(file_idx).battery(bat_idx).voltage = filtered_voltage;
    end

    % Помечаем фазу давления
    if ismember(file_idx, increasing_idx)
        full_data(file_idx).phase = 'increasing';
        filtered_data(file_idx).phase = 'increasing';
    else
        full_data(file_idx).phase = 'decreasing';
        filtered_data(file_idx).phase = 'decreasing';
    end
end

%% Функция для подготовки данных поверхности с правильной осью экспериментов
function [X, Y, Z, success] = prepare_experiment_surface(pressure_values, all_data, bat_idx, method)
    % Используем индекс эксперимента как ось Y
    experiment_indices = 1:length(pressure_values);

    % Собираем все временные точки для определения общей сетки
    all_times = [];
    for idx = 1:length(all_data)
        if ~isempty(all_data(idx).battery(bat_idx).time) && length(all_data(idx).battery(bat_idx).time) >= 2
            all_times = [all_times; all_data(idx).battery(bat_idx).time];
        end
    end

    if isempty(all_times)
        X = []; Y = []; Z = []; success = false;
        return;
    end

    % Создаем общую временную сетки
    min_time = min(all_times);
    max_time = max(all_times);

    if min_time == max_time
        X = []; Y = []; Z = []; success = false;
        return;
    end

    time_grid = linspace(min_time, max_time, 100);

    % Создаем матрицы для поверхности
    Z = NaN(length(experiment_indices), length(time_grid));

    % Создаем правильные сетки X и Y
    [X, Y] = meshgrid(time_grid, experiment_indices);

    % Интерполяция данных на общую сетку для всех файлов
    valid_points = 0;
    for idx = 1:length(all_data)
        current_time = all_data(idx).battery(bat_idx).time;
        current_voltage = all_data(idx).battery(bat_idx).voltage;

        if length(current_time) >= 2
            try
                % Удаляем дубликаты времени для интерполяции
                [unique_time, unique_idx] = unique(current_time, 'stable');
                unique_voltage = current_voltage(unique_idx);

                if length(unique_time) >= 2
                    % Интерполяция на общую сетку
                    interpolated_voltage = interp1(unique_time, unique_voltage, time_grid, method, NaN);
                    Z(idx, :) = interpolated_voltage;
                    valid_points = valid_points + sum(~isnan(interpolated_voltage));
                end
            catch ME
                fprintf('   Ошибка интерполяции для файла %d: %s\n', idx, ME.message);
            end
        end
    end

    success = valid_points > 20; % Минимум 20 валидных точек
end

%% Функция для безопасного построения поверхности с правильными подписями экспериментов
function safe_surf_with_experiment_labels(X, Y, Z, plot_title, pressure_values, increasing_idx, decreasing_idx)
    try
        % Проверяем размеры матриц
        if ~isequal(size(X), size(Y), size(Z))
            fprintf('   Размеры не совпадают: X=%s, Y=%s, Z=%s\n', ...
                    mat2str(size(X)), mat2str(size(Y)), mat2str(size(Z)));
            text(0.5, 0.5, 'Ошибка размеров данных', 'HorizontalAlignment', 'center', 'FontSize', 14);
            return;
        end

        % Проверяем наличие валидных данных
        if all(isnan(Z(:)))
            text(0.5, 0.5, 'Нет валидных данных для поверхности', 'HorizontalAlignment', 'center', 'FontSize', 14);
            return;
        end

        % Строим поверхность
        surf(X, Y, Z, 'EdgeColor', 'none');

        % Устанавливаем правильные подписи по оси Y - индексы экспериментов с давлениями
        experiment_labels = cell(1, length(pressure_values));
        for i = 1:length(pressure_values)
            if ismember(i, increasing_idx)
                experiment_labels{i} = sprintf('Exp%d: %d↑', i, pressure_values(i));
            else
                experiment_labels{i} = sprintf('Exp%d: %d↓', i, pressure_values(i));
            end
        end

        yticks(1:length(pressure_values));
        yticklabels(experiment_labels);

        xlabel('Время, ч', 'FontSize', 14, 'FontWeight', 'bold');
        ylabel('Эксперимент (Давление)', 'FontSize', 14, 'FontWeight', 'bold');
        zlabel('Напряжение, В', 'FontSize', 14, 'FontWeight', 'bold');
        title(plot_title, 'FontSize', 16, 'FontWeight', 'bold');
        colorbar;
        set(gca, 'FontSize', 12);

        % Настраиваем вид для лучшей визуализации
        view(45, 30);
        grid on;

        % Добавляем информацию о разделении фаз
        [~, max_idx] = max(pressure_values);
        hold on;
        if max_idx < length(pressure_values)
            % Линия, разделяющая фазы
            max_pressure_line = plot3([X(1,1), X(1,end)], ...
                                     [max_idx, max_idx], ...
                                     [max(Z(:)), max(Z(:))], 'r-', 'LineWidth', 3);
            legend(max_pressure_line, 'Разделение фаз', 'Location', 'northeast', 'FontSize', 12);
        end

    catch ME
        fprintf('   Ошибка при построении поверхности: %s\n', ME.message);
        text(0.5, 0.5, sprintf('Ошибка: %s', ME.message), 'HorizontalAlignment', 'center', 'FontSize', 14);
    end
end

%% Функция для построения графика качества данных с группировкой по давлениям
function plot_quality_data(data_quality, pressure_values, bat_idx, plot_title)
    % Группируем данные по уникальным давлениям
    unique_pressures = unique(pressure_values);
    avg_quality = zeros(size(unique_pressures));

    for i = 1:length(unique_pressures)
        p = unique_pressures(i);
        % Находим все файлы с этим давлением
        pressure_indices = find(pressure_values == p);
        valid_ratios = [];

        for j = 1:length(pressure_indices)
            idx = pressure_indices(j);
            if idx <= length(data_quality) && ~isempty(data_quality(idx).battery)
                valid_ratios(end+1) = data_quality(idx).battery(bat_idx).valid_ratio * 100;
            end
        end

        if ~isempty(valid_ratios)
            avg_quality(i) = mean(valid_ratios);
        else
            avg_quality(i) = 0;
        end
    end

    % Строим график
    if any(avg_quality > 0)
        bar(unique_pressures, avg_quality);
        xlabel('Давление', 'FontSize', 14, 'FontWeight', 'bold');
        ylabel('Валидные данные (%)', 'FontSize', 14, 'FontWeight', 'bold');
        title([plot_title ' - Качество данных'], 'FontSize', 16, 'FontWeight', 'bold');
        grid on;
        ylim([0 100]);
        set(gca, 'FontSize', 12);

        % Добавляем числовые подписи на столбцы
        for i = 1:length(unique_pressures)
            if avg_quality(i) > 0
                text(unique_pressures(i), avg_quality(i) + 2, ...
                     sprintf('%.1f%%', avg_quality(i)), ...
                     'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');
            end
        end
    else
        text(0.5, 0.5, 'Нет данных о качестве', 'HorizontalAlignment', 'center', 'FontSize', 14);
        title([plot_title ' - Качество данных'], 'FontSize', 16, 'FontWeight', 'bold');
    end
end

%% Функция для построения графиков с правильной поверхностью (УЛУЧШЕННАЯ ВЕРСИЯ)
function plot_battery_data_with_surface(data, pressure_values, increasing_idx, decreasing_idx, ...
                                       data_quality, bat_idx, plot_title)
    num_files = length(data);

    % УЛУЧШЕННЫЕ ЦВЕТА - более контрастные и различимые
    colors_inc = [0, 0.4470, 0.7410;     % Темно-синий
                  0.8500, 0.3250, 0.0980; % Темно-оранжевый
                  0.9290, 0.6940, 0.1250; % Золотой
                  0.4940, 0.1840, 0.5560; % Фиолетовый
                  0.4660, 0.6740, 0.1880; % Зеленый
                  0.3010, 0.7450, 0.9330; % Голубой
                  0.6350, 0.0780, 0.1840]; % Бордовый

    colors_dec = [0.8500, 0.3250, 0.0980; % Темно-оранжевый
                  0.9290, 0.6940, 0.1250; % Золотой
                  0.4940, 0.1840, 0.5560; % Фиолетовый
                  0.4660, 0.6740, 0.1880; % Зеленый
                  0.3010, 0.7450, 0.9330; % Голубой
                  0.6350, 0.0780, 0.1840; % Бордовый
                  0, 0.4470, 0.7410];    % Темно-синий

    % 2D графики с разделением по фазам - ЛЕГЕНДА ВНЕ ГРАФИКА
    %subplot(2, 2, 1);
    figure
    hold on;

    legend_handles = [];
    legend_labels = {};

    % Возрастающая фаза
    for i = 1:length(increasing_idx)
        idx = increasing_idx(i);
        if ~isempty(data(idx).battery(bat_idx).time) && ~isempty(data(idx).battery(bat_idx).voltage)
            color_idx = mod(i-1, size(colors_inc, 1)) + 1;
            h = plot(data(idx).battery(bat_idx).time, data(idx).battery(bat_idx).voltage, ...
                 'Color', colors_inc(color_idx, :), 'LineWidth', 2.5);
            legend_handles(end+1) = h;
            legend_labels{end+1} = sprintf('P=%d↑ (%dт.)', data(idx).pressure, ...
                 length(data(idx).battery(bat_idx).time));
        end
    end

    % Убывающая фаза
    for i = 1:length(decreasing_idx)
        idx = decreasing_idx(i);
        if ~isempty(data(idx).battery(bat_idx).time) && ~isempty(data(idx).battery(bat_idx).voltage)
            color_idx = mod(i-1, size(colors_dec, 1)) + 1;
            h = plot(data(idx).battery(bat_idx).time, data(idx).battery(bat_idx).voltage, ...
                 'Color', colors_dec(color_idx, :), 'LineWidth', 2.5, 'LineStyle', '--');
            legend_handles(end+1) = h;
            legend_labels{end+1} = sprintf('P=%d↓ (%dт.)', data(idx).pressure, ...
                 length(data(idx).battery(bat_idx).time));
        end
    end

    xlabel('Время, ч', 'FontSize', 14, 'FontWeight', 'bold');
    ylabel('Напряжение, В', 'FontSize', 14, 'FontWeight', 'bold');
    title(plot_title, 'FontSize', 16, 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 12);

    % Добавляем легенду ВНЕ графика с увеличенным шрифтом
    if ~isempty(legend_handles)
        legend(legend_handles, legend_labels, 'Location', 'eastoutside', 'FontSize', 10);
    end

    % 3D поверхность с правильной осью экспериментов
    figure
    hold on
    %subplot(2, 2, 2);
    [X_full, Y_full, Z_full, success] = prepare_experiment_surface(pressure_values, data, bat_idx, 'linear');

    if success
        safe_surf_with_experiment_labels(X_full, Y_full, Z_full, plot_title, ...
                                       pressure_values, increasing_idx, decreasing_idx);
    else
        text(0.5, 0.5, 'Недостаточно данных для 3D', 'HorizontalAlignment', 'center', 'FontSize', 14);
        title('Напряжение vs. Время vs. Давление', 'FontSize', 16, 'FontWeight', 'bold');
    end

    % Сравнительные графики для ключевых давлений - ЛЕГЕНДА ВНЕ ГРАФИКА
    figure
    %subplot(2, 2, 3);
    hold on;

    % Выбираем характерные давления для сравнения
    unique_pressures = unique(pressure_values);
    if length(unique_pressures) >= 3
        selected_pressures = [min(unique_pressures), median(unique_pressures), max(unique_pressures)];
    else
        selected_pressures = unique_pressures;
    end

    colors = {'b', 'r', 'g', 'm', 'c'};
    comp_legend_handles = [];
    comp_legend_labels = {};
    has_data = false;

    for i = 1:length(selected_pressures)
        p = selected_pressures(i);
        pressure_indices = find(pressure_values == p);

        for j = 1:length(pressure_indices)
            idx = pressure_indices(j);
            if ~isempty(data(idx).battery(bat_idx).time) && ~isempty(data(idx).battery(bat_idx).voltage)
                phase_symbol = '↑';
                line_style = '-';
                if ismember(idx, decreasing_idx)
                    phase_symbol = '↓';
                    line_style = '--';
                end

                h = plot(data(idx).battery(bat_idx).time, data(idx).battery(bat_idx).voltage, ...
                     colors{i}, 'LineWidth', 2.5, 'LineStyle', line_style);

                if j == 1
                    comp_legend_handles(end+1) = h;
                    comp_legend_labels{end+1} = sprintf('P=%d', p);
                end
                has_data = true;
            end
        end
    end

    if has_data
        xlabel('Время, ч', 'FontSize', 14, 'FontWeight', 'bold');
        ylabel('Напряжение, В', 'FontSize', 14, 'FontWeight', 'bold');
        title('Сравнение ключевых давлений', 'FontSize', 16, 'FontWeight', 'bold');
        grid on;
        set(gca, 'FontSize', 12);

        % Легенда ВНЕ графика
        if ~isempty(comp_legend_handles)
            legend(comp_legend_handles, comp_legend_labels, 'Location', 'eastoutside', 'FontSize', 12);
        end
    else
        text(0.5, 0.5, 'Нет данных для сравнения', 'HorizontalAlignment', 'center', 'FontSize', 14);
        title('Сравнение ключевых давлений', 'FontSize', 16, 'FontWeight', 'bold');
    end

    % График зависимости конечного напряжения от давления - ЛЕГЕНДА ВНЕ ГРАФИКА
    %subplot(2, 2, 4);
    figure
    hold on;

    end_voltages_inc = [];
    end_pressures_inc = [];
    end_voltages_dec = [];
    end_pressures_dec = [];

    has_inc_data = false;
    has_dec_data = false;

    for idx = 1:num_files
        if ~isempty(data(idx).battery(bat_idx).voltage)
            if ismember(idx, increasing_idx)
                end_voltages_inc(end+1) = data(idx).battery(bat_idx).voltage(end);
                end_pressures_inc(end+1) = pressure_values(idx);
                has_inc_data = true;
            else
                end_voltages_dec(end+1) = data(idx).battery(bat_idx).voltage(end);
                end_pressures_dec(end+1) = pressure_values(idx);
                has_dec_data = true;
            end
        end
    end

    voltage_legend_handles = [];
    voltage_legend_labels = {};

    if has_inc_data || has_dec_data
        if has_inc_data
            % Сортируем по давлению для правильного соединения линий
            [end_pressures_inc, sort_idx] = sort(end_pressures_inc);
            end_voltages_inc = end_voltages_inc(sort_idx);
            h1 = plot(end_pressures_inc, end_voltages_inc, 'bo-', 'MarkerSize', 8, 'LineWidth', 2.5, 'MarkerFaceColor', 'blue');
            voltage_legend_handles(end+1) = h1;
            voltage_legend_labels{end+1} = 'Возрастание';
        end

        if has_dec_data
            % Сортируем по давлению для правильного соединения линий
            [end_pressures_dec, sort_idx] = sort(end_pressures_dec);
            end_voltages_dec = end_voltages_dec(sort_idx);
            h2 = plot(end_pressures_dec, end_voltages_dec, 'ro-', 'MarkerSize', 8, 'LineWidth', 2.5, 'MarkerFaceColor', 'red');
            voltage_legend_handles(end+1) = h2;
            voltage_legend_labels{end+1} = 'Убывание';
        end

        xlabel('Давление', 'FontSize', 14, 'FontWeight', 'bold');
        ylabel('Конечное напряжение, В', 'FontSize', 14, 'FontWeight', 'bold');
        title('Конечное напряжение vs давление', 'FontSize', 16, 'FontWeight', 'bold');
        grid on;
        set(gca, 'FontSize', 12);

        % Легенда ВНЕ графика
        if ~isempty(voltage_legend_handles)
            legend(voltage_legend_handles, voltage_legend_labels, 'Location', 'eastoutside', 'FontSize', 12);
        end
    else
        text(0.5, 0.5, 'Нет данных', 'HorizontalAlignment', 'center', 'FontSize', 14);
        title('Конечное напряжение vs давление', 'FontSize', 16, 'FontWeight', 'bold');
    end
end

%% Построение графиков разрядных характеристик
if (is_draw_dch == 1)
    fprintf('\n=== ПОСТРОЕНИЕ ГРАФИКОВ РАЗРЯДНЫХ ХАРАКТЕРИСТИК ===\n');

    % Построение графиков для каждого аккумулятора (полные данные)
    for bat_idx = 1:num_batteries
        plot_battery_data_with_surface(full_data, pressure_values, increasing_idx, decreasing_idx, ...
                                     data_quality, bat_idx, sprintf('Аккумулятор %d - Полные данные', bat_idx));
    end

    % Построение графиков для каждого аккумулятора (отфильтрованные данные)
    for bat_idx = 1:num_batteries
        plot_battery_data_with_surface(filtered_data, pressure_values, increasing_idx, decreasing_idx, ...
                                     data_quality, bat_idx, sprintf('Аккумулятор %d (время ≥ %.3f ч)', bat_idx, start_time));
    end

    %% Отчет о качестве данных
    fprintf('\n=== ОТЧЕТ О КАЧЕСТВЕ ДАННЫХ ===\n');
    for bat_idx = 1:num_batteries
        fprintf('\nАккумулятор %d:\n', bat_idx);
        total_original = 0;
        total_clean = 0;

        for file_idx = 1:num_files
            if file_idx <= length(data_quality) && ~isempty(data_quality(file_idx).battery)
                orig = data_quality(file_idx).battery(bat_idx).original_points;
                clean = data_quality(file_idx).battery(bat_idx).clean_points;
                ratio = data_quality(file_idx).battery(bat_idx).valid_ratio * 100;

                total_original = total_original + orig;
                total_clean = total_clean + clean;

                fprintf('   Файл %d (P=%d): %d -> %d точек (%.1f%%)\n', ...
                    file_idx, pressure_values(file_idx), orig, clean, ratio);
            end
        end

        if total_original > 0
            overall_ratio = total_clean / total_original * 100;
            fprintf('   ИТОГО: %d -> %d точек (%.1f%% валидных)\n', ...
                total_original, total_clean, overall_ratio);
        else
            fprintf('   ИТОГО: нет данных\n');
        end
    end

    fprintf('\nПостроение разрядных характеристик завершено.\n');
end

%% Статистический анализ
fprintf('\n\n=== СТАТИСТИЧЕСКИЙ АНАЛИЗ ===\n');

%% Функция для вычисления ключевых характеристик разрядной кривой
function features = extract_discharge_features(time, voltage, discharge_current)
    features = struct();

    if length(time) < 2 || length(voltage) < 2
        features.is_valid = false;
        return;
    end

    features.is_valid = true;

    % Базовые характеристики (время в часах)
    features.initial_voltage = voltage(1);
    features.final_voltage = voltage(end);
    features.duration = time(end) - time(1); % в часах
    features.voltage_drop = voltage(1) - voltage(end);

    % Производная (скорость разряда в В/ч)
    dt = diff(time);
    dv = diff(voltage);
    dvdt = dv ./ dt;

    % Характеристики производной
    features.max_discharge_rate = max(abs(dvdt));
    features.avg_discharge_rate = mean(abs(dvdt));
    features.final_discharge_rate = abs(dvdt(end));

    % Энергетические характеристики
    features.area_under_curve = trapz(time, voltage); % В·ч

    % Емкость в А·ч (время уже в часах)
    features.capacity_Ah = trapz(time, voltage) / mean(voltage) * discharge_current;

    % Энергия в Вт·ч
    features.energy_Wh = features.capacity_Ah * mean(voltage);

    % Статистические характеристики
    features.voltage_std = std(voltage);
    features.voltage_variance = var(voltage);
end

%% Извлечение характеристик для всех данных
fprintf('\nИзвлечение характеристик разрядных кривых...\n');

all_features = struct();

for bat_idx = 1:num_batteries
    fprintf('Аккумулятор %d: ', bat_idx);

    for file_idx = 1:num_files
        time_data = filtered_data(file_idx).battery(bat_idx).time;
        voltage_data = filtered_data(file_idx).battery(bat_idx).voltage;

        all_features(file_idx).battery(bat_idx) = extract_discharge_features(time_data, voltage_data, discharge_current);

        if all_features(file_idx).battery(bat_idx).is_valid
            fprintf('✓');
        else
            fprintf('✗');
        end
    end
    fprintf('\n');
end

%% Вспомогательные функции для статистического анализа

% Функция для вычисления корреляции с p-value в Octave
function [r, p_val] = corr_octave(x, y)
    % Удаляем NaN значения
    valid_mask = ~isnan(x) & ~isnan(y);
    x_clean = x(valid_mask);
    y_clean = y(valid_mask);

    if length(x_clean) < 3
        r = NaN;
        p_val = NaN;
        return;
    end

    % Вычисляем коэффициент корреляции Пирсона вручную
    x_mean = mean(x_clean);
    y_mean = mean(y_clean);
    x_std = std(x_clean);
    y_std = std(y_clean);

    if x_std == 0 || y_std == 0
        r = NaN;
        p_val = NaN;
        return;
    end

    % Ручной расчет корреляции
    covariance = mean((x_clean - x_mean) .* (y_clean - y_mean));
    r = covariance / (x_std * y_std);

    % Упрощенное вычисление p-value
    n = length(x_clean);
    if n > 2 && abs(r) < 1
        % Используем приближенную формулу для p-value
        t_stat = abs(r) * sqrt((n-2) / (1 - r^2));
        % Эмпирическая аппроксимация p-value для больших n
        p_val = 2 * exp(-0.717 * t_stat - 0.416 * t_stat^2);
        % Ограничиваем p-value диапазоном [0, 1]
        p_val = max(0, min(1, p_val));
    else
        p_val = NaN;
    end
end

% Функция для звездочек значимости
function star = get_significance_star(p_value)
    if isnan(p_value)
        star = ' (NaN)';
    elseif p_value < 0.001
        star = ' ***';
    elseif p_value < 0.01
        star = ' **';
    elseif p_value < 0.05
        star = ' *';
    else
        star = '';
    end
end

%% Корреляционный анализ по фазам
fprintf('\n=== КОРРЕЛЯЦИОННЫЙ АНАЛИЗ ПО ФАЗАМ ===\n');

correlation_results = struct();

for bat_idx = 1:num_batteries
    fprintf('\n--- Аккумулятор %d ---\n', bat_idx);

    % Разделяем данные по фазам
    pressures_inc = [];
    pressures_dec = [];
    initial_voltages_inc = [];
    initial_voltages_dec = [];
    final_voltages_inc = [];
    final_voltages_dec = [];
    discharge_rates_inc = [];
    discharge_rates_dec = [];
    durations_inc = [];
    durations_dec = [];
    areas_inc = [];
    areas_dec = [];
    capacities_inc = [];
    capacities_dec = [];
    energies_inc = [];
    energies_dec = [];

    % Собираем данные раздельно для каждой фазы
    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            current_pressure = pressure_values(file_idx);

            if ismember(file_idx, increasing_idx)
                pressures_inc(end+1) = current_pressure;
                initial_voltages_inc(end+1) = all_features(file_idx).battery(bat_idx).initial_voltage;
                final_voltages_inc(end+1) = all_features(file_idx).battery(bat_idx).final_voltage;
                discharge_rates_inc(end+1) = all_features(file_idx).battery(bat_idx).avg_discharge_rate;
                durations_inc(end+1) = all_features(file_idx).battery(bat_idx).duration;
                areas_inc(end+1) = all_features(file_idx).battery(bat_idx).area_under_curve;
                capacities_inc(end+1) = all_features(file_idx).battery(bat_idx).capacity_Ah;
                energies_inc(end+1) = all_features(file_idx).battery(bat_idx).energy_Wh;
            else
                pressures_dec(end+1) = current_pressure;
                initial_voltages_dec(end+1) = all_features(file_idx).battery(bat_idx).initial_voltage;
                final_voltages_dec(end+1) = all_features(file_idx).battery(bat_idx).final_voltage;
                discharge_rates_dec(end+1) = all_features(file_idx).battery(bat_idx).avg_discharge_rate;
                durations_dec(end+1) = all_features(file_idx).battery(bat_idx).duration;
                areas_dec(end+1) = all_features(file_idx).battery(bat_idx).area_under_curve;
                capacities_dec(end+1) = all_features(file_idx).battery(bat_idx).capacity_Ah;
                energies_dec(end+1) = all_features(file_idx).battery(bat_idx).energy_Wh;
            end
        end
    end

    fprintf('  Возрастающая фаза: %d точек\n', length(pressures_inc));
    fprintf('  Убывающая фаза: %d точек\n', length(pressures_dec));

    % Анализ для каждой фазы отдельно
    corr_matrix_inc = [];
    corr_matrix_dec = [];

    if length(pressures_inc) >= 3
        [corr_initial_inc, p_initial_inc] = corr_octave(pressures_inc, initial_voltages_inc);
        [corr_final_inc, p_final_inc] = corr_octave(pressures_inc, final_voltages_inc);
        [corr_rate_inc, p_rate_inc] = corr_octave(pressures_inc, discharge_rates_inc);
        [corr_duration_inc, p_duration_inc] = corr_octave(pressures_inc, durations_inc);
        [corr_area_inc, p_area_inc] = corr_octave(pressures_inc, areas_inc);
        [corr_capacity_inc, p_capacity_inc] = corr_octave(pressures_inc, capacities_inc);
        [corr_energy_inc, p_energy_inc] = corr_octave(pressures_inc, energies_inc);

        corr_matrix_inc = [corr_initial_inc, corr_final_inc, corr_rate_inc, corr_duration_inc, corr_area_inc, corr_capacity_inc, corr_energy_inc];

        fprintf('  ВОЗРАСТАЮЩАЯ фаза - корреляция с давлением:\n');
        fprintf('    Начальное напряжение: r=%.3f (p=%.4f)%s\n', ...
            corr_initial_inc, p_initial_inc, get_significance_star(p_initial_inc));
        fprintf('    Конечное напряжение:   r=%.3f (p=%.4f)%s\n', ...
            corr_final_inc, p_final_inc, get_significance_star(p_final_inc));
        fprintf('    Скорость разряда:      r=%.3f (p=%.4f)%s\n', ...
            corr_rate_inc, p_rate_inc, get_significance_star(p_rate_inc));
        fprintf('    Длительность:          r=%.3f (p=%.4f)%s\n', ...
            corr_duration_inc, p_duration_inc, get_significance_star(p_duration_inc));
        fprintf('    Энергоемкость:         r=%.3f (p=%.4f)%s\n', ...
            corr_area_inc, p_area_inc, get_significance_star(p_area_inc));
        fprintf('    Емкость:               r=%.3f (p=%.4f)%s\n', ...
            corr_capacity_inc, p_capacity_inc, get_significance_star(p_capacity_inc));
        fprintf('    Энергия:               r=%.3f (p=%.4f)%s\n', ...
            corr_energy_inc, p_energy_inc, get_significance_star(p_energy_inc));
    else
        fprintf('  ВОЗРАСТАЮЩАЯ фаза: недостаточно данных для корреляции\n');
    end

    if length(pressures_dec) >= 3
        [corr_initial_dec, p_initial_dec] = corr_octave(pressures_dec, initial_voltages_dec);
        [corr_final_dec, p_final_dec] = corr_octave(pressures_dec, final_voltages_dec);
        [corr_rate_dec, p_rate_dec] = corr_octave(pressures_dec, discharge_rates_dec);
        [corr_duration_dec, p_duration_dec] = corr_octave(pressures_dec, durations_dec);
        [corr_area_dec, p_area_dec] = corr_octave(pressures_dec, areas_dec);
        [corr_capacity_dec, p_capacity_dec] = corr_octave(pressures_dec, capacities_dec);
        [corr_energy_dec, p_energy_dec] = corr_octave(pressures_dec, energies_dec);

        corr_matrix_dec = [corr_initial_dec, corr_final_dec, corr_rate_dec, corr_duration_dec, corr_area_dec, corr_capacity_dec, corr_energy_dec];

        fprintf('  УБЫВАЮЩАЯ фаза - корреляция с давлением:\n');
        fprintf('    Начальное напряжение: r=%.3f (p=%.4f)%s\n', ...
            corr_initial_dec, p_initial_dec, get_significance_star(p_initial_dec));
        fprintf('    Конечное напряжение:   r=%.3f (p=%.4f)%s\n', ...
            corr_final_dec, p_final_dec, get_significance_star(p_final_dec));
        fprintf('    Скорость разряда:      r=%.3f (p=%.4f)%s\n', ...
            corr_rate_dec, p_rate_dec, get_significance_star(p_rate_dec));
        fprintf('    Длительность:          r=%.3f (p=%.4f)%s\n', ...
            corr_duration_dec, p_duration_dec, get_significance_star(p_duration_dec));
        fprintf('    Энергоемкость:         r=%.3f (p=%.4f)%s\n', ...
            corr_area_dec, p_area_dec, get_significance_star(p_area_dec));
        fprintf('    Емкость:               r=%.3f (p=%.4f)%s\n', ...
            corr_capacity_dec, p_capacity_dec, get_significance_star(p_capacity_dec));
        fprintf('    Энергия:               r=%.3f (p=%.4f)%s\n', ...
            corr_energy_dec, p_energy_dec, get_significance_star(p_energy_dec));
    else
        fprintf('  УБЫВАЮЩАЯ фаза: недостаточно данных для корреляции\n');
    end

    % Сохраняем результаты
    correlation_results(bat_idx).pressures_inc = pressures_inc;
    correlation_results(bat_idx).pressures_dec = pressures_dec;
    correlation_results(bat_idx).initial_voltages_inc = initial_voltages_inc;
    correlation_results(bat_idx).initial_voltages_dec = initial_voltages_dec;
    correlation_results(bat_idx).final_voltages_inc = final_voltages_inc;
    correlation_results(bat_idx).final_voltages_dec = final_voltages_dec;
    correlation_results(bat_idx).areas_inc = areas_inc;
    correlation_results(bat_idx).areas_dec = areas_dec;
    correlation_results(bat_idx).corr_matrix_inc = corr_matrix_inc;
    correlation_results(bat_idx).corr_matrix_dec = corr_matrix_dec;
end













%% Расширенный статистический анализ с R², F-статистикой и таблицей результатов
fprintf('\n=== РАСШИРЕННЫЙ СТАТИСТИЧЕСКИЙ АНАЛИЗ ===\n');

% Функция для линейной регрессии с расчетом R² и F-статистики
function [r_squared, f_stat, f_pval, coefficients, stats] = linear_regression_stats(x, y)
    % Удаляем NaN значения
    valid_mask = ~isnan(x) & ~isnan(y);
    x_clean = x(valid_mask);
    y_clean = y(valid_mask);

    if length(x_clean) < 3
        r_squared = NaN;
        f_stat = NaN;
        f_pval = NaN;
        coefficients = [NaN, NaN];
        stats = struct();
        return;
    end

    % Линейная регрессия
    X = [ones(length(x_clean), 1), x_clean(:)];
    [coefficients, ~, ~, ~, stats] = regress(y_clean(:), X);

    r_squared = stats(1);
    f_stat = stats(2);
    f_pval = stats(3);
end

% Создаем таблицу для сводных результатов
extended_stats = struct();

for bat_idx = 1:num_batteries
    fprintf('\n--- Расширенный анализ для АКБ %d ---\n', bat_idx);

    % Подготовка данных для таблицы
    feature_names = {'Начальное_напряжение', 'Конечное_напряжение', 'Скорость_разряда', ...
                    'Длительность', 'Энергоемкость', 'Емкость'};

    % Инициализация таблиц для каждой фазы
    stats_table_inc = [];
    stats_table_dec = [];

    % Собираем данные напрямую из all_features для возрастающей фазы
    pressures_inc = [];
    initial_voltages_inc = [];
    final_voltages_inc = [];
    discharge_rates_inc = [];
    durations_inc = [];
    areas_inc = [];
    capacities_inc = [];

    for file_idx = increasing_idx
        if all_features(file_idx).battery(bat_idx).is_valid
            pressures_inc(end+1) = pressure_values(file_idx);
            initial_voltages_inc(end+1) = all_features(file_idx).battery(bat_idx).initial_voltage;
            final_voltages_inc(end+1) = all_features(file_idx).battery(bat_idx).final_voltage;
            discharge_rates_inc(end+1) = all_features(file_idx).battery(bat_idx).avg_discharge_rate;
            durations_inc(end+1) = all_features(file_idx).battery(bat_idx).duration;
            areas_inc(end+1) = all_features(file_idx).battery(bat_idx).area_under_curve;
            capacities_inc(end+1) = all_features(file_idx).battery(bat_idx).capacity_Ah;
        end
    end

    % Собираем данные напрямую из all_features для убывающей фазы
    pressures_dec = [];
    initial_voltages_dec = [];
    final_voltages_dec = [];
    discharge_rates_dec = [];
    durations_dec = [];
    areas_dec = [];
    capacities_dec = [];

    for file_idx = decreasing_idx
        if all_features(file_idx).battery(bat_idx).is_valid
            pressures_dec(end+1) = pressure_values(file_idx);
            initial_voltages_dec(end+1) = all_features(file_idx).battery(bat_idx).initial_voltage;
            final_voltages_dec(end+1) = all_features(file_idx).battery(bat_idx).final_voltage;
            discharge_rates_dec(end+1) = all_features(file_idx).battery(bat_idx).avg_discharge_rate;
            durations_dec(end+1) = all_features(file_idx).battery(bat_idx).duration;
            areas_dec(end+1) = all_features(file_idx).battery(bat_idx).area_under_curve;
            capacities_dec(end+1) = all_features(file_idx).battery(bat_idx).capacity_Ah;
        end
    end

    % Анализ для возрастающей фазы
    if length(pressures_inc) >= 3
        fprintf('\n  ВОЗРАСТАЮЩАЯ ФАЗА: %d точек\n', length(pressures_inc));
        fprintf('    %-20s %-8s %-8s %-8s %-8s %-8s\n', 'Характеристика', 'r', 'R²', 'p-value', 'F-стат', 'F-pval');
        fprintf('    %s\n', repmat('-', 1, 70));

        features_data = {
            initial_voltages_inc,
            final_voltages_inc,
            discharge_rates_inc,
            durations_inc,
            areas_inc,
            capacities_inc
        };

        for feat_idx = 1:length(feature_names)
            y_data = features_data{feat_idx};

            if length(y_data) >= 3 && length(pressures_inc) == length(y_data)
                % Корреляция
                [r, p_val] = corr_octave(pressures_inc, y_data);

                % Линейная регрессия
                [r_squared, f_stat, f_pval, coeffs, reg_stats] = linear_regression_stats(pressures_inc, y_data);

                % Сохраняем в таблицу
                stats_table_inc(feat_idx, :) = [r, r_squared, p_val, f_stat, f_pval];

                fprintf('    %-20s %-8.3f %-8.3f %-8.4f %-8.2f %-8.4f%s\n', ...
                    feature_names{feat_idx}, r, r_squared, p_val, f_stat, f_pval, get_significance_star(p_val));
            else
                stats_table_inc(feat_idx, :) = [NaN, NaN, NaN, NaN, NaN];
                fprintf('    %-20s %-8s %-8s %-8s %-8s %-8s\n', ...
                    feature_names{feat_idx}, 'NaN', 'NaN', 'NaN', 'NaN', 'NaN');
            end
        end
    else
        fprintf('  ВОЗРАСТАЮЩАЯ ФАЗА: недостаточно данных (%d точек)\n', length(pressures_inc));
    end

    % Анализ для убывающей фазы
    if length(pressures_dec) >= 3
        fprintf('\n  УБЫВАЮЩАЯ ФАЗА: %d точек\n', length(pressures_dec));
        fprintf('    %-20s %-8s %-8s %-8s %-8s %-8s\n', 'Характеристика', 'r', 'R²', 'p-value', 'F-стат', 'F-pval');
        fprintf('    %s\n', repmat('-', 1, 70));

        features_data = {
            initial_voltages_dec,
            final_voltages_dec,
            discharge_rates_dec,
            durations_dec,
            areas_dec,
            capacities_dec
        };

        for feat_idx = 1:length(feature_names)
            y_data = features_data{feat_idx};

            if length(y_data) >= 3 && length(pressures_dec) == length(y_data)
                % Корреляция
                [r, p_val] = corr_octave(pressures_dec, y_data);

                % Линейная регрессия
                [r_squared, f_stat, f_pval, coeffs, reg_stats] = linear_regression_stats(pressures_dec, y_data);

                % Сохраняем в таблицу
                stats_table_dec(feat_idx, :) = [r, r_squared, p_val, f_stat, f_pval];

                fprintf('    %-20s %-8.3f %-8.3f %-8.4f %-8.2f %-8.4f%s\n', ...
                    feature_names{feat_idx}, r, r_squared, p_val, f_stat, f_pval, get_significance_star(p_val));
            else
                stats_table_dec(feat_idx, :) = [NaN, NaN, NaN, NaN, NaN];
                fprintf('    %-20s %-8s %-8s %-8s %-8s %-8s\n', ...
                    feature_names{feat_idx}, 'NaN', 'NaN', 'NaN', 'NaN', 'NaN');
            end
        end
    else
        fprintf('  УБЫВАЮЩАЯ ФАЗА: недостаточно данных (%d точек)\n', length(pressures_dec));
    end

    % Сохраняем результаты
    extended_stats(bat_idx).feature_names = feature_names;
    extended_stats(bat_idx).stats_table_inc = stats_table_inc;
    extended_stats(bat_idx).stats_table_dec = stats_table_dec;
    extended_stats(bat_idx).pressures_inc = pressures_inc;
    extended_stats(bat_idx).pressures_dec = pressures_dec;
end

%% Визуализация расширенной статистики в виде таблиц
fprintf('\n=== ВИЗУАЛИЗАЦИЯ РАСШИРЕННОЙ СТАТИСТИКИ ===\n');

for bat_idx = 1:num_batteries
    has_inc_data = ~isempty(extended_stats(bat_idx).stats_table_inc) && any(~isnan(extended_stats(bat_idx).stats_table_inc(:)));
    has_dec_data = ~isempty(extended_stats(bat_idx).stats_table_dec) && any(~isnan(extended_stats(bat_idx).stats_table_dec(:)));

    if has_inc_data || has_dec_data
        figure('Name', sprintf('Расширенная статистика - АКБ %d', bat_idx), ...
               'Position', [100, 100, 1200, 600]);

        feature_names = extended_stats(bat_idx).feature_names;

        % Возрастающая фаза
        if has_inc_data
            subplot(1, 2, 1);

            table_data = extended_stats(bat_idx).stats_table_inc;
            valid_rows = any(~isnan(table_data), 2);

            if any(valid_rows)
                table_data = table_data(valid_rows, :);
                feature_names_inc = feature_names(valid_rows);

                % Создаем тепловую карту для визуализации
                imagesc(table_data, [-1, 1]);
                colorbar;
                title('Возрастающая фаза - Статистические показатели', 'FontSize', 14, 'FontWeight', 'bold');
                xlabel('Показатели', 'FontSize', 12, 'FontWeight', 'bold');
                ylabel('Характеристики', 'FontSize', 12, 'FontWeight', 'bold');

                column_names = {'r', 'R²', 'p-value', 'F-стат', 'F-pval'};
                set(gca, 'XTick', 1:5, 'XTickLabel', column_names, 'FontSize', 10);
                set(gca, 'YTick', 1:size(table_data, 1), 'YTickLabel', feature_names_inc, 'FontSize', 9);

                % Добавляем числовые значения
                for i = 1:size(table_data, 1)
                    for j = 1:size(table_data, 2)
                        if ~isnan(table_data(i,j))
                            if j == 3 || j == 5 % p-value столбцы
                                if table_data(i,j) < 0.05
                                    text_color = 'white';
                                else
                                    text_color = 'black';
                                end
                            else
                                if abs(table_data(i,j)) > 0.5
                                    text_color = 'white';
                                else
                                    text_color = 'black';
                                end
                            end

                            if j == 1 || j == 2 % r и R²
                                text_str = sprintf('%.3f', table_data(i,j));
                            else % p-value и F-статистика
                                text_str = sprintf('%.4f', table_data(i,j));
                            end

                            text(j, i, text_str, 'HorizontalAlignment', 'center', ...
                                'FontSize', 8, 'FontWeight', 'bold', 'Color', text_color);
                        end
                    end
                end
            end
        else
            subplot(1, 2, 1);
            text(0.5, 0.5, 'Нет данных для возрастающей фазы', ...
                 'HorizontalAlignment', 'center', 'FontSize', 14, 'FontWeight', 'bold');
            title('Возрастающая фаза', 'FontSize', 14, 'FontWeight', 'bold');
            axis off;
        end

        % Убывающая фаза
        if has_dec_data
            subplot(1, 2, 2);

            table_data = extended_stats(bat_idx).stats_table_dec;
            valid_rows = any(~isnan(table_data), 2);

            if any(valid_rows)
                table_data = table_data(valid_rows, :);
                feature_names_dec = feature_names(valid_rows);

                % Создаем тепловую карту для визуализации
                imagesc(table_data, [-1, 1]);
                colorbar;
                title('Убывающая фаза - Статистические показатели', 'FontSize', 14, 'FontWeight', 'bold');
                xlabel('Показатели', 'FontSize', 12, 'FontWeight', 'bold');
                ylabel('Характеристики', 'FontSize', 12, 'FontWeight', 'bold');

                column_names = {'r', 'R²', 'p-value', 'F-стат', 'F-pval'};
                set(gca, 'XTick', 1:5, 'XTickLabel', column_names, 'FontSize', 10);
                set(gca, 'YTick', 1:size(table_data, 1), 'YTickLabel', feature_names_dec, 'FontSize', 9);

                % Добавляем числовые значения
                for i = 1:size(table_data, 1)
                    for j = 1:size(table_data, 2)
                        if ~isnan(table_data(i,j))
                            if j == 3 || j == 5 % p-value столбцы
                                if table_data(i,j) < 0.05
                                    text_color = 'white';
                                else
                                    text_color = 'black';
                                end
                            else
                                if abs(table_data(i,j)) > 0.5
                                    text_color = 'white';
                                else
                                    text_color = 'black';
                                end
                            end

                            if j == 1 || j == 2 % r и R²
                                text_str = sprintf('%.3f', table_data(i,j));
                            else % p-value и F-статистика
                                text_str = sprintf('%.4f', table_data(i,j));
                            end

                            text(j, i, text_str, 'HorizontalAlignment', 'center', ...
                                'FontSize', 8, 'FontWeight', 'bold', 'Color', text_color);
                        end
                    end
                end
            end
        else
            subplot(1, 2, 2);
            text(0.5, 0.5, 'Нет данных для убывающей фазы', ...
                 'HorizontalAlignment', 'center', 'FontSize', 14, 'FontWeight', 'bold');
            title('Убывающая фаза', 'FontSize', 14, 'FontWeight', 'bold');
            axis off;
        end
    end
end

%% Сохранение расширенной статистики в CSV файлы
fprintf('\n=== СОХРАНЕНИЕ РЕЗУЛЬТАТОВ В ФАЙЛЫ ===\n');

for bat_idx = 1:num_batteries
    has_inc_data = ~isempty(extended_stats(bat_idx).stats_table_inc) && any(~isnan(extended_stats(bat_idx).stats_table_inc(:)));
    has_dec_data = ~isempty(extended_stats(bat_idx).stats_table_dec) && any(~isnan(extended_stats(bat_idx).stats_table_dec(:)));

    if has_inc_data || has_dec_data
        % Сохраняем данные для возрастающей фазы
        if has_inc_data
            filename_inc = sprintf('extended_stats_battery_%d_increasing.csv', bat_idx);

            % Создаем таблицу для сохранения
            table_data = extended_stats(bat_idx).stats_table_inc;
            feature_names = extended_stats(bat_idx).feature_names;

            % Открываем файл для записи
            fid = fopen(filename_inc, 'w');
            fprintf(fid, 'Feature,Correlation_r,R_squared,p_value,F_statistic,F_p_value\n');

            for i = 1:size(table_data, 1)
                if any(~isnan(table_data(i,:)))
                    fprintf(fid, '%s,%.6f,%.6f,%.6f,%.6f,%.6f\n', ...
                        feature_names{i}, table_data(i,1), table_data(i,2), table_data(i,3), table_data(i,4), table_data(i,5));
                end
            end

            fclose(fid);
            fprintf('Сохранен файл: %s\n', filename_inc);
        end

        % Сохраняем данные для убывающей фазы
        if has_dec_data
            filename_dec = sprintf('extended_stats_battery_%d_decreasing.csv', bat_idx);

            % Создаем таблицу для сохранения
            table_data = extended_stats(bat_idx).stats_table_dec;
            feature_names = extended_stats(bat_idx).feature_names;

            % Открываем файл для записи
            fid = fopen(filename_dec, 'w');
            fprintf(fid, 'Feature,Correlation_r,R_squared,p_value,F_statistic,F_p_value\n');

            for i = 1:size(table_data, 1)
                if any(~isnan(table_data(i,:)))
                    fprintf(fid, '%s,%.6f,%.6f,%.6f,%.6f,%.6f\n', ...
                        feature_names{i}, table_data(i,1), table_data(i,2), table_data(i,3), table_data(i,4), table_data(i,5));
                end
            end

            fclose(fid);
            fprintf('Сохранен файл: %s\n', filename_dec);
        end
    end
end


















%% Сводные матрицы корреляций для всех АКБ с временем разряда
fprintf('\n=== СВОДНЫЕ МАТРИЦЫ КОРРЕЛЯЦИЙ ДЛЯ ВСЕХ АКБ (С ВРЕМЕНЕМ РАЗРЯДА) ===\n');

% Собираем все матрицы корреляций с временем разряда
all_corr_inc = [];
all_corr_dec = [];
bat_labels = {};

for bat_idx = 1:num_batteries
    if ~isempty(correlation_results(bat_idx).corr_matrix_inc) && ~isempty(correlation_results(bat_idx).corr_matrix_dec)
        % Берем только первые 6 характеристик, исключая дублирующую энергию
        all_corr_inc(bat_idx, :) = correlation_results(bat_idx).corr_matrix_inc(1:6);
        all_corr_dec(bat_idx, :) = correlation_results(bat_idx).corr_matrix_dec(1:6);
        bat_labels{bat_idx} = sprintf('АКБ%d', bat_idx);
    end
end

if ~isempty(all_corr_inc) && ~isempty(all_corr_dec)
    figure('Name', 'Сводные матрицы корреляций всех АКБ (с временем разряда)', 'Position', [100, 100, 1400, 600]);

    feature_names = {'Нач.напр', 'Кон.напр', 'Скор.разр', 'Длит.', 'Энерг.', 'Емк.'};


       % Матрица для возрастающей фазы
    subplot(1, 2, 1);
    imagesc(all_corr_inc, [-1, 1]);
    colorbar;
    title('Возрастающая фаза - все АКБ', 'FontSize', 16, 'FontWeight', 'bold');
    xlabel('Характеристики', 'FontSize', 14, 'FontWeight', 'bold');
    ylabel('Аккумуляторы', 'FontSize', 14, 'FontWeight', 'bold');
    set(gca, 'XTick', 1:6, 'XTickLabel', feature_names, 'FontSize', 10);  % Изменено с 7 на 6
    set(gca, 'YTick', 1:size(all_corr_inc, 1), 'YTickLabel', bat_labels, 'FontSize', 12);

    % Добавляем числовые значения
    for i = 1:size(all_corr_inc, 1)
        for j = 1:size(all_corr_inc, 2)  % Теперь размерность 6
            if abs(all_corr_inc(i,j)) > 0.5
                text_color = 'white';
            else
                text_color = 'black';
            end
            text(j, i, sprintf('%.2f', all_corr_inc(i,j)), ...
                'HorizontalAlignment', 'center', 'FontSize', 8, 'FontWeight', 'bold', ...
                'Color', text_color);
        end
    end

    % Матрица для убывающей фазы
    subplot(1, 2, 2);
    imagesc(all_corr_dec, [-1, 1]);
    colorbar;
    title('Убывающая фаза - все АКБ', 'FontSize', 16, 'FontWeight', 'bold');
    xlabel('Характеристики', 'FontSize', 14, 'FontWeight', 'bold');
    ylabel('Аккумуляторы', 'FontSize', 14, 'FontWeight', 'bold');
    set(gca, 'XTick', 1:6, 'XTickLabel', feature_names, 'FontSize', 10);  % Изменено с 7 на 6
    set(gca, 'YTick', 1:size(all_corr_dec, 1), 'YTickLabel', bat_labels, 'FontSize', 12);

    % Добавляем числовые значения
    for i = 1:size(all_corr_dec, 1)
        for j = 1:size(all_corr_dec, 2)  % Теперь размерность 6
            if abs(all_corr_dec(i,j)) > 0.5
                text_color = 'white';
            else
                text_color = 'black';
            end
            text(j, i, sprintf('%.2f', all_corr_dec(i,j)), ...
                'HorizontalAlignment', 'center', 'FontSize', 8, 'FontWeight', 'bold', ...
                'Color', text_color);
        end
    end

else
    fprintf('  Недостаточно данных для сводных матриц корреляций\n');
end

%% Сводные графики для всех АКБ с временем разряда
fprintf('\n\n=== СВОДНЫЙ АНАЛИЗ ДЛЯ ВСЕХ АКБ (С ВРЕМЕНЕМ РАЗРЯДА) ===\n');

pressure_sequence = pressure_values;
experiment_order = 1:num_files;

% Цвета для разных аккумуляторов
bat_colors = {'b', 'r', 'g', 'm', 'c', 'k', 'y'};
bat_markers = {'o', 's', '^', 'd', 'v', '>', '<'};

%% 1. Сводный график времени разряда для всех АКБ
figure('Name', 'Сводный анализ - Время разряда всех АКБ', 'Position', [100, 100, 1400, 800]);
hold on;
legend_handles = [];
legend_entries = {};

for bat_idx = 1:num_batteries
    exp_indices = [];
    durations = [];

    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            exp_indices(end+1) = file_idx;
            durations(end+1) = all_features(file_idx).battery(bat_idx).duration;
        end
    end

    if ~isempty(exp_indices)
        [exp_indices, sort_idx] = sort(exp_indices);
        durations = durations(sort_idx);

        h = plot(exp_indices, durations, [bat_colors{bat_idx} '-'], ...
                 'Marker', bat_markers{bat_idx}, 'MarkerSize', 8, 'LineWidth', 2);
        legend_handles(end+1) = h;
        legend_entries{end+1} = sprintf('АКБ %d', bat_idx);
    end
end

xlabel('Номер эксперимента', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Время разряда, ч', 'FontSize', 16, 'FontWeight', 'bold');
title('Время разряда всех АКБ', 'FontSize', 18, 'FontWeight', 'bold');
xticks(1:num_files);
xticklabels(arrayfun(@(x) sprintf('E%d\n%d', x, pressure_sequence(x)), 1:num_files, 'UniformOutput', false));

[~, max_idx] = max(pressure_sequence);
if max_idx < num_files
    y_lim = ylim;
    plot([max_idx+0.5, max_idx+0.5], [y_lim(1), y_lim(2)], 'r-', 'LineWidth', 3);
    text(max_idx+0.5, y_lim(2)*0.98, 'Смена фазы', 'HorizontalAlignment', 'center', ...
         'BackgroundColor', 'white', 'FontSize', 14, 'FontWeight', 'bold');
end

legend(legend_handles, legend_entries, 'Location', 'eastoutside', 'FontSize', 14);
grid on;
set(gca, 'FontSize', 14);

%% 2. Сводный график скорости разряда для всех АКБ
figure('Name', 'Сводный анализ - Скорость разряда всех АКБ', 'Position', [100, 100, 1400, 800]);
hold on;
legend_handles = [];
legend_entries = {};

for bat_idx = 1:num_batteries
    exp_indices = [];
    discharge_rates = [];

    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            exp_indices(end+1) = file_idx;
            discharge_rates(end+1) = all_features(file_idx).battery(bat_idx).avg_discharge_rate;
        end
    end

    if ~isempty(exp_indices)
        [exp_indices, sort_idx] = sort(exp_indices);
        discharge_rates = discharge_rates(sort_idx);

        h = plot(exp_indices, discharge_rates, [bat_colors{bat_idx} '-'], ...
                 'Marker', bat_markers{bat_idx}, 'MarkerSize', 8, 'LineWidth', 2);
        legend_handles(end+1) = h;
        legend_entries{end+1} = sprintf('АКБ %d', bat_idx);
    end
end

xlabel('Номер эксперимента', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Средняя скорость разряда, В/ч', 'FontSize', 16, 'FontWeight', 'bold');
title('Скорость разряда всех АКБ', 'FontSize', 18, 'FontWeight', 'bold');
xticks(1:num_files);
xticklabels(arrayfun(@(x) sprintf('E%d\n%d', x, pressure_sequence(x)), 1:num_files, 'UniformOutput', false));

[~, max_idx] = max(pressure_sequence);
if max_idx < num_files
    y_lim = ylim;
    plot([max_idx+0.5, max_idx+0.5], [y_lim(1), y_lim(2)], 'r-', 'LineWidth', 3);
    text(max_idx+0.5, y_lim(2)*0.98, 'Смена фазы', 'HorizontalAlignment', 'center', ...
         'BackgroundColor', 'white', 'FontSize', 14, 'FontWeight', 'bold');
end

legend(legend_handles, legend_entries, 'Location', 'eastoutside', 'FontSize', 14);
grid on;
set(gca, 'FontSize', 14);

%% 3. Сводный график емкости для всех АКБ
figure('Name', 'Сводный анализ - Емкость всех АКБ', 'Position', [100, 100, 1400, 800]);
hold on;
legend_handles = [];
legend_entries = {};

for bat_idx = 1:num_batteries
    exp_indices = [];
    capacities = [];

    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            exp_indices(end+1) = file_idx;
            capacities(end+1) = all_features(file_idx).battery(bat_idx).capacity_Ah;
        end
    end

    if ~isempty(exp_indices)
        [exp_indices, sort_idx] = sort(exp_indices);
        capacities = capacities(sort_idx);

        h = plot(exp_indices, capacities, [bat_colors{bat_idx} '-'], ...
                 'Marker', bat_markers{bat_idx}, 'MarkerSize', 8, 'LineWidth', 2);
        legend_handles(end+1) = h;
        legend_entries{end+1} = sprintf('АКБ %d', bat_idx);
    end
end

xlabel('Номер эксперимента', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Емкость, А·ч', 'FontSize', 16, 'FontWeight', 'bold');
title('Емкость всех АКБ (Iразр = 0.39 А)', 'FontSize', 18, 'FontWeight', 'bold');
xticks(1:num_files);
xticklabels(arrayfun(@(x) sprintf('E%d\n%d', x, pressure_sequence(x)), 1:num_files, 'UniformOutput', false));

[~, max_idx] = max(pressure_sequence);
if max_idx < num_files
    y_lim = ylim;
    plot([max_idx+0.5, max_idx+0.5], [y_lim(1), y_lim(2)], 'r-', 'LineWidth', 3);
    text(max_idx+0.5, y_lim(2)*0.98, 'Смена фазы', 'HorizontalAlignment', 'center', ...
         'BackgroundColor', 'white', 'FontSize', 14, 'FontWeight', 'bold');
end

legend(legend_handles, legend_entries, 'Location', 'eastoutside', 'FontSize', 14);
grid on;
set(gca, 'FontSize', 14);

%% 4. Сводный график энергоемкости для всех АКБ
figure('Name', 'Сводный анализ - Энергоемкость всех АКБ', 'Position', [100, 100, 1400, 800]);
hold on;

for bat_idx = 1:num_batteries
    exp_indices = [];
    energies = [];

    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            exp_indices(end+1) = file_idx;
            energies(end+1) = all_features(file_idx).battery(bat_idx).energy_Wh;
        end
    end

    if ~isempty(exp_indices)
        [exp_indices, sort_idx] = sort(exp_indices);
        energies = energies(sort_idx);
        plot(exp_indices, energies, [bat_colors{bat_idx} '-^'], ...
             'MarkerSize', 8, 'LineWidth', 2);
    end
end

xlabel('Номер эксперимента', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Энергия, Вт·ч', 'FontSize', 16, 'FontWeight', 'bold');
title('Энергия всех АКБ (Iразр = 0.39 А)', 'FontSize', 18, 'FontWeight', 'bold');
xticks(1:num_files);
xticklabels(arrayfun(@(x) sprintf('E%d\n%d', x, pressure_sequence(x)), 1:num_files, 'UniformOutput', false));

if max_idx < num_files
    y_lim = ylim;
    plot([max_idx+0.5, max_idx+0.5], [y_lim(1), y_lim(2)], 'r-', 'LineWidth', 3);
end

legend(legend_entries, 'Location', 'eastoutside', 'FontSize', 14);
grid on;
set(gca, 'FontSize', 14);

%% 5. Сводный график гистерезиса времени разряда для всех АКБ
figure('Name', 'Сводный анализ - Гистерезис времени разряда', 'Position', [100, 100, 1600, 1000]);

for bat_idx = 1:num_batteries
    subplot(2, 3, bat_idx);
    hold on;

    pressures_inc = [];
    durations_inc = [];
    pressures_dec = [];
    durations_dec = [];

    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            current_pressure = pressure_values(file_idx);
            if ismember(file_idx, increasing_idx)
                pressures_inc(end+1) = current_pressure;
                durations_inc(end+1) = all_features(file_idx).battery(bat_idx).duration;
            else
                pressures_dec(end+1) = current_pressure;
                durations_dec(end+1) = all_features(file_idx).battery(bat_idx).duration;
            end
        end
    end

    if ~isempty(pressures_inc)
        [pressures_inc, sort_idx] = sort(pressures_inc);
        durations_inc = durations_inc(sort_idx);
        plot(pressures_inc, durations_inc, 'bo-', 'MarkerSize', 8, 'LineWidth', 2, 'MarkerFaceColor', 'blue');
    end

    if ~isempty(pressures_dec)
        [pressures_dec, sort_idx] = sort(pressures_dec);
        durations_dec = durations_dec(sort_idx);
        plot(pressures_dec, durations_dec, 'ro--', 'MarkerSize', 8, 'LineWidth', 2, 'MarkerFaceColor', 'red');
    end

    xlabel('Давление', 'FontSize', 14, 'FontWeight', 'bold');
    ylabel('Время разряда, ч', 'FontSize', 14, 'FontWeight', 'bold');
    title(sprintf('АКБ %d: Гистерезис времени разряда', bat_idx), 'FontSize', 16, 'FontWeight', 'bold');
    unique_pressures = unique(pressure_values);
    xticks(unique_pressures);
    xticklabels(arrayfun(@(x) sprintf('%d', x), unique_pressures, 'UniformOutput', false));




    max_pressure = max(pressure_values);
    y_lim = ylim;
    plot([max_pressure, max_pressure], [y_lim(1), y_lim(2)], 'k-', 'LineWidth', 2, 'Color', [0.5 0.5 0.5]);
    text(max_pressure, (y_lim(1) + y_lim(2)) / 2, 'Смена фазы', 'HorizontalAlignment', 'center', ...
         'BackgroundColor', 'white', 'FontSize', 10, 'FontWeight', 'bold', 'Rotation', 90);





    legend('Возрастание', 'Убывание', 'Location', 'best', 'FontSize', 12);
    grid on;
    set(gca, 'FontSize', 12);

    if ~isempty(durations_inc) && ~isempty(durations_dec)
        common_pressures = intersect(pressures_inc, pressures_dec);
        hysteresis_diffs = [];

        for p = common_pressures
            inc_idx = find(pressures_inc == p, 1);
            dec_idx = find(pressures_dec == p, 1);

            if ~isempty(inc_idx) && ~isempty(dec_idx)
                hysteresis_diffs(end+1) = durations_dec(dec_idx) - durations_inc(inc_idx);
            end
        end

        if ~isempty(hysteresis_diffs)
            avg_hysteresis = mean(hysteresis_diffs);
            % Увеличиваем точность отображения до 6 знаков после запятой
            text(0.05, 0.95, sprintf('Ср. гистерезис: %.5f ч', avg_hysteresis), ...
                 'Units', 'normalized', 'FontSize', 10, 'BackgroundColor', 'white', 'FontWeight', 'bold');
        end
    end
end

%% 6. Сводный график гистерезиса емкости для всех АКБ
figure('Name', 'Сводный анализ - Гистерезис емкости', 'Position', [100, 100, 1600, 1000]);

for bat_idx = 1:num_batteries
    subplot(2, 3, bat_idx);
    hold on;

    pressures_inc = [];
    capacities_inc = [];
    pressures_dec = [];
    capacities_dec = [];

    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            current_pressure = pressure_values(file_idx);
            if ismember(file_idx, increasing_idx)
                pressures_inc(end+1) = current_pressure;
                capacities_inc(end+1) = all_features(file_idx).battery(bat_idx).capacity_Ah;
            else
                pressures_dec(end+1) = current_pressure;
                capacities_dec(end+1) = all_features(file_idx).battery(bat_idx).capacity_Ah;
            end
        end
    end

    if ~isempty(pressures_inc)
        [pressures_inc, sort_idx] = sort(pressures_inc);
        capacities_inc = capacities_inc(sort_idx);
        plot(pressures_inc, capacities_inc, 'bo-', 'MarkerSize', 8, 'LineWidth', 2, 'MarkerFaceColor', 'blue');
    end

    if ~isempty(pressures_dec)
        [pressures_dec, sort_idx] = sort(pressures_dec);
        capacities_dec = capacities_dec(sort_idx);
        plot(pressures_dec, capacities_dec, 'ro--', 'MarkerSize', 8, 'LineWidth', 2, 'MarkerFaceColor', 'red');
    end

    xlabel('Давление', 'FontSize', 14, 'FontWeight', 'bold');
    ylabel('Емкость, А·ч', 'FontSize', 14, 'FontWeight', 'bold');
    title(sprintf('АКБ %d: Гистерезис емкости', bat_idx), 'FontSize', 16, 'FontWeight', 'bold');
    unique_pressures = unique(pressure_values);
    xticks(unique_pressures);
    xticklabels(arrayfun(@(x) sprintf('%d', x), unique_pressures, 'UniformOutput', false));


    %%

    max_pressure = max(pressure_values);
    y_lim = ylim;
    plot([max_pressure, max_pressure], [y_lim(1), y_lim(2)], 'k-', 'LineWidth', 2, 'Color', [0.5 0.5 0.5]);
    text(max_pressure, (y_lim(1) + y_lim(2)) / 2, 'Смена фазы', 'HorizontalAlignment', 'center', ...
         'BackgroundColor', 'white', 'FontSize', 10, 'FontWeight', 'bold', 'Rotation', 90);

    %%


    legend('Возрастание', 'Убывание', 'Location', 'best', 'FontSize', 12);
    grid on;
    set(gca, 'FontSize', 12);

    if ~isempty(capacities_inc) && ~isempty(capacities_dec)
        common_pressures = intersect(pressures_inc, pressures_dec);
        hysteresis_diffs = [];

        for p = common_pressures
            inc_idx = find(pressures_inc == p, 1);
            dec_idx = find(pressures_dec == p, 1);

            if ~isempty(inc_idx) && ~isempty(dec_idx)
                hysteresis_diffs(end+1) = capacities_dec(dec_idx) - capacities_inc(inc_idx);
            end
        end

        if ~isempty(hysteresis_diffs)
            avg_hysteresis = mean(hysteresis_diffs);
            % Увеличиваем точность отображения до 6 знаков после запятой
            text(0.05, 0.95, sprintf('Ср. гистерезис: %.4f А·ч', avg_hysteresis), ...
                 'Units', 'normalized', 'FontSize', 10, 'BackgroundColor', 'white', 'FontWeight', 'bold');
        end
    end
end

%% 7. Сравнение стабильности АКБ по стандартному отклонению напряжения
figure('Name', 'Сводный анализ - Стабильность напряжения АКБ', 'Position', [100, 100, 1000, 600]);
hold on;

stability_data = [];
bat_labels = {};

for bat_idx = 1:num_batteries
    voltage_stds = [];

    for file_idx = 1:num_files
        if all_features(file_idx).battery(bat_idx).is_valid
            voltage_stds(end+1) = all_features(file_idx).battery(bat_idx).voltage_std;
        end
    end

    if ~isempty(voltage_stds)
        stability_data(bat_idx) = mean(voltage_stds);
    else
        stability_data(bat_idx) = NaN;
    end
    bat_labels{bat_idx} = sprintf('АКБ%d', bat_idx);
end

if ~isempty(stability_data) && any(~isnan(stability_data))
    valid_data = ~isnan(stability_data);
    bar(stability_data(valid_data));

    xlabel('Аккумулятор', 'FontSize', 16, 'FontWeight', 'bold');
    ylabel('Среднее STD напряжения, В', 'FontSize', 16, 'FontWeight', 'bold');
    title('Стабильность напряжения АКБ', 'FontSize', 18, 'FontWeight', 'bold');
    set(gca, 'XTick', 1:sum(valid_data), 'XTickLabel', bat_labels(valid_data), 'FontSize', 14);
    grid on;
    set(gca, 'FontSize', 14);

    % Добавляем числовые подписи
    for i = 1:length(stability_data)
        if ~isnan(stability_data(i))
            text(i, stability_data(i) + 0.001, sprintf('%.4f', stability_data(i)), ...
                'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold');
        end
    end

    % Добавляем информацию о количестве экспериментов
    text(0.02, 0.98, sprintf('Всего экспериментов: %d\nТок разряда: %.3f А', num_files, discharge_current), ...
         'Units', 'normalized', 'FontSize', 12, 'BackgroundColor', 'white', ...
         'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
else
    text(0.5, 0.5, 'Нет данных о стабильности', 'HorizontalAlignment', 'center', ...
         'FontSize', 16, 'FontWeight', 'bold');
    title('Стабильность напряжения АКБ', 'FontSize', 18, 'FontWeight', 'bold');
end

fprintf('\nАнализ завершен!\n');

















%% Создание общей сводной таблицы для всех АКБ
fprintf('\n=== ОБЩАЯ СВОДНАЯ ТАБЛИЦА ДЛЯ ВСЕХ АКБ ===\n');

% Создаем общую таблицу
summary_data = {};
row_counter = 1;

% Заголовки столбцов
headers = {'АКБ', 'Фаза', 'Характеристика', 'r', 'R2', 'p_value', 'F_stat', 'F_pval', 'Значимость'};

for bat_idx = 1:num_batteries
    % Данные для возрастающей фазы
    if ~isempty(extended_stats(bat_idx).stats_table_inc)
        table_data = extended_stats(bat_idx).stats_table_inc;
        feature_names = extended_stats(bat_idx).feature_names;

        for feat_idx = 1:size(table_data, 1)
            if any(~isnan(table_data(feat_idx, :)))
                r = table_data(feat_idx, 1);
                r2 = table_data(feat_idx, 2);
                p_val = table_data(feat_idx, 3);
                f_stat = table_data(feat_idx, 4);
                f_pval = table_data(feat_idx, 5);

                % Определяем значимость
                if p_val < 0.001
                    significance = '***';
                elseif p_val < 0.01
                    significance = '**';
                elseif p_val < 0.05
                    significance = '*';
                else
                    significance = '';
                end

                summary_data{row_counter, 1} = bat_idx;
                summary_data{row_counter, 2} = 'Возрастание';
                summary_data{row_counter, 3} = feature_names{feat_idx};
                summary_data{row_counter, 4} = r;
                summary_data{row_counter, 5} = r2;
                summary_data{row_counter, 6} = p_val;
                summary_data{row_counter, 7} = f_stat;
                summary_data{row_counter, 8} = f_pval;
                summary_data{row_counter, 9} = significance;

                row_counter = row_counter + 1;
            end
        end
    end

    % Данные для убывающей фазы
    if ~isempty(extended_stats(bat_idx).stats_table_dec)
        table_data = extended_stats(bat_idx).stats_table_dec;
        feature_names = extended_stats(bat_idx).feature_names;

        for feat_idx = 1:size(table_data, 1)
            if any(~isnan(table_data(feat_idx, :)))
                r = table_data(feat_idx, 1);
                r2 = table_data(feat_idx, 2);
                p_val = table_data(feat_idx, 3);
                f_stat = table_data(feat_idx, 4);
                f_pval = table_data(feat_idx, 5);

                % Определяем значимость
                if p_val < 0.001
                    significance = '***';
                elseif p_val < 0.01
                    significance = '**';
                elseif p_val < 0.05
                    significance = '*';
                else
                    significance = '';
                end

                summary_data{row_counter, 1} = bat_idx;
                summary_data{row_counter, 2} = 'Убывание';
                summary_data{row_counter, 3} = feature_names{feat_idx};
                summary_data{row_counter, 4} = r;
                summary_data{row_counter, 5} = r2;
                summary_data{row_counter, 6} = p_val;
                summary_data{row_counter, 7} = f_stat;
                summary_data{row_counter, 8} = f_pval;
                summary_data{row_counter, 9} = significance;

                row_counter = row_counter + 1;
            end
        end
    end
end

% Сохраняем общую таблицу в CSV файл
if ~isempty(summary_data)
    filename = 'summary_statistics_all_batteries.csv';

    fid = fopen(filename, 'w');
    % Записываем заголовки
    fprintf(fid, '%s,%s,%s,%s,%s,%s,%s,%s,%s\n', headers{:});

    % Записываем данные
    for i = 1:size(summary_data, 1)
        fprintf(fid, '%d,%s,%s,%.6f,%.6f,%.6f,%.6f,%.6f,%s\n', ...
            summary_data{i, 1}, summary_data{i, 2}, summary_data{i, 3}, ...
            summary_data{i, 4}, summary_data{i, 5}, summary_data{i, 6}, ...
            summary_data{i, 7}, summary_data{i, 8}, summary_data{i, 9});
    end

    fclose(fid);
    fprintf('Общая сводная таблица сохранена в файл: %s\n', filename);
    fprintf('Всего записей: %d\n', size(summary_data, 1));

    % Выводим краткую статистику в командное окно
    fprintf('\nКраткая статистика по файлу:\n');
    fprintf('Всего АКБ: %d\n', num_batteries);
    fprintf('Всего записей: %d\n', size(summary_data, 1));

    % Подсчет значимых результатов
    significant_count = sum(cellfun(@(x) ~isempty(x), summary_data(:, 9)));
    fprintf('Значимых результатов (p < 0.05): %d (%.1f%%)\n', ...
        significant_count, significant_count/size(summary_data, 1)*100);
else
    fprintf('Нет данных для создания общей таблицы\n');
end
































diary off
